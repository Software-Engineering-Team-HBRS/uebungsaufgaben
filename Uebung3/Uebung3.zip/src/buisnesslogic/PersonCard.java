package buisnesslogic;


public interface PersonCard {
    public String getFirstName();
    public String getLastName();
    public int getId();
}

