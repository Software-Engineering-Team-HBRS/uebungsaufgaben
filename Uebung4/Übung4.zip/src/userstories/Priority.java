package userstories;

public enum Priority {

    must,
    should,
    could,
    won_t;
}
