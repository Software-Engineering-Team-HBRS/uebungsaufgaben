package buisnesslogic;

public class CardBoxException extends Exception {
    public CardBoxException(String message) {
        super(message);
    }
}
