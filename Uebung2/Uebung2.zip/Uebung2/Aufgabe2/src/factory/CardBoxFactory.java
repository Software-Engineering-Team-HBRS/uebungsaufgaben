package factory;

import buisnesslogic.CardBox;

public class CardBoxFactory {
    public static CardBox createCardBox() {
        return new CardBox();
    }
}
